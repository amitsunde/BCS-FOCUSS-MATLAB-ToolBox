function out = individual_focuss(y,phi,b,m,n,xold,number_iter)
% See:  Amit Satish Unde and Deepthi P. P., "Block compressive sensing: Individual and joint reconstruction
%of correlated images," Elsevier Journal of Visual Communication and Image Representation, 2017
% This program is free software; you can redistribute it and/or modify it 
% Email : amitsunde@gmail.com

d_pre = 500;
[m1 n1] = size(y);
psi = dctmtx2(b);
z1 = psi'; z2 = psi * phi'; z3 = phi * psi';
tol = 0.00001;  
for iter = 1:number_iter
    
    x1 = col2im(xold, [b b],[m n], 'distinct'); 
    x_hat = wiener2(x1, [3, 3]);
    xold = im2col(x_hat, [b b], 'distinct');
    
    pitmp = psi * xold;
    pitmp = abs(pitmp);
    
    for i=1:n1
        z=y(:,i);
        pimain=diag(pitmp(:,i));
        tmp= z3 * diag(pitmp(:,i)) * z2;
        [ytt(:,i) xx] = minres(tmp,z);
    end
    
    
   xnew = psi'*(pitmp.*(z2*ytt)); 

  
   d_new=RMS(xold,xnew);
  
  
   if (d_new>d_pre)
       xold=xold_pre;
       break;
   end
    d_pre=d_new;
     
    xold=xnew;
    xold_pre=xnew;
    
end
out = col2im(xold, [b b], [m n], 'distict');